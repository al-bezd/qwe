from django.contrib.auth.models import User, Group
from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.reverse import reverse
from rest_framework.response import Response

from check_send.models import PostOffices, Cartriges, Dispatch
from serializer import UserSerializer, PostSerializer, CartrigeSerializer,DispatchSerializer

@api_view(['GET'])
def api_root(request, format=None):
    return Response({
        'users': reverse('check_send:user-list', request=request),
        'postoficces': reverse('check_send:postoficce-list', request=request),
        'cartridgies':reverse('check_send:cartridgie-list', request=request),
        'dispatch': reverse('check_send:dispatch-list', request=request),
    })

class UserList(generics.ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    queryset = User.objects.all()

class UserDetail(generics.RetrieveUpdateDestroyAPIView):
    model = User
    serializer_class = UserSerializer
    queryset = User.objects.all()

class PostList(generics.ListCreateAPIView):
    model = PostOffices
    serializer_class = PostSerializer
    queryset = PostOffices.objects.all()

class PostDetail(generics.RetrieveUpdateDestroyAPIView):
    model = PostOffices
    serializer_class = PostSerializer
    queryset = PostOffices.objects.all()
    lookup_field = 'index'

class CartrigesList(generics.ListCreateAPIView):
    model = Cartriges
    serializer_class = CartrigeSerializer
    queryset = Cartriges.objects.all()
    #lookup_field = 'model'

class CartridgieDetail(generics.RetrieveUpdateDestroyAPIView):
    model = Cartriges
    serializer_class = CartrigeSerializer
    queryset = Cartriges.objects.all()
    lookup_field = 'model'

class DispatchList(generics.ListCreateAPIView):
    model = Dispatch
    serializer_class = DispatchSerializer
    queryset = Dispatch.objects.all().order_by("-disp_date").order_by("-id")[0:100]
    #lookup_field = 'model'

class DispatchDetail(generics.RetrieveUpdateDestroyAPIView):
    model = Dispatch
    serializer_class = DispatchSerializer
    queryset = Dispatch.objects.all()
    #lookup_field = 'model'

