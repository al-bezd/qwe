from django.contrib.auth.models import User
from rest_framework import serializers
from rest_framework.fields import Field

from check_send.models import PostOffices, Cartriges, Dispatch


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'email', 'groups')

class PostSerializer(serializers.HyperlinkedModelSerializer):
    name = serializers.ReadOnlyField(source='name', read_only=True),
    index = serializers.ReadOnlyField(source='index', read_only=True),
    class Meta:
        model = PostOffices
        fields = ('index', 'name', 'date_add')
        lookup_field = 'index'

class CartrigeSerializer(serializers.HyperlinkedModelSerializer):
    type = serializers.ReadOnlyField(source='type.name', read_only=True)
    class Meta:
        model = Cartriges
        fields = ('model','date_add','type')
        lookup_field='model'

class DispatchSerializer(serializers.HyperlinkedModelSerializer):
    post_office = serializers.ReadOnlyField(source='get_office', read_only=True)
    post_index = serializers.ReadOnlyField(source='get_index', read_only=True)
    model = serializers.ReadOnlyField(source='model.model', read_only=True)
    class Meta:
        model = Dispatch
        fields = ('id','post_office','post_index','model','amount','disp_date','status')