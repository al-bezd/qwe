#coding:utf8
from __future__ import unicode_literals

from django.apps import AppConfig


class CheckSendConfig(AppConfig):
    name = 'check_send'
    verbose_name = 'Регистр отправлений'
